const char* dgemm_desc = "Naive, three-loop dgemm.";

/*
  This routine performs a dgemm operation
  C := C + A * B
  where A, B, and C are lda-by-lda matrices stored in column-major format.
  On exit, A and B maintain their input values.
 */

void square_dgemm(const int M, const double *A, const double *B, double *C)
{
    int i, j, k;
    // For each row i of A
    for (i = 0; i < M; ++i) {
        // For each column j of B
        for (j = 0; j < M; ++j) {
            // Compute C(i,j)
            double cij = C[i + j*M];
            for (k = 0; k < M; ++k)
                cij += A[i+ k*M] * B[k + j*M];
            C[i + j*M] = cij;
        }
    }
}
