set ylabel "Performance (Gflop/sec)"
set xlabel "Matrix Dimension (N)"
set title "N by N Matrix Multiply (Bridges-2)"
set grid ytics
set grid xtics
set yrange [0:50]
set term postscript color
set output "timing.eps"
plot "timing-naive.csv" using 1:($2/1000) t "Naive" with linespoint,\
     "timing-blocked.csv" using 1:($2/1000) t "Blocked" with linespoint,\
     "timing-blas.csv" using 1:($2/1000) t "Blas" with linespoint

